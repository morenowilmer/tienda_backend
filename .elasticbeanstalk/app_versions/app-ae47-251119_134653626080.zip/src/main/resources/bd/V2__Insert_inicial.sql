INSERT INTO tipo_documento(id, nombre, valor, activo)
values (1, "Cédula de ciudadanía", "CEDULA", "S");
INSERT INTO tipo_documento(id, nombre, valor, activo)
values (2, "Cédula de extranjera", "EXTRAN", "S");
INSERT INTO tipo_documento(id, nombre, valor, activo)
values (3, "Pasaporte", "PASAPO", "S");
INSERT INTO tipo_documento(id, nombre, valor, activo)
values (4, "Tarjeta de identidad", "TARIDE", "S");